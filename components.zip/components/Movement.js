AFRAME.registerComponent("plane-movement", {
    schema:{
        RotateValue: { type:"number", default:0 },
        PositionValue: { type:"number", default:0 }
    },
    init: function() {
        window.addEventListener("keydown", (e) => {
            this.data.RotateValue = this.el.getAttribute("rotation");
            this.data.PositionValue = this.el.getAttribute("position")
            var planeRotation = this.data.RotateValue
            var planePos = this.data.PositionValue

            if(e.key === "ArrowRight") {
                if(planeRotation.y < 0.01) {
                    planeRotation.y -= 5
                    this.el.setAttribute("rotation", planeRotation)
                }
            }
            
            if(e.key === "ArrowLeft") {
                if(planeRotation.y > -0.01) {
                    planeRotation.y += 1.5
                    this.el.setAttribute("rotation", planeRotation)
                }
            }
            
            if(e.key === "ArrowUp") {
                if(planeRotation.x < 40) {
                    planeRotation.x += 2
                    this.el.setAttribute("rotation", planeRotation)
                }
                
                // if(planeRotation.z < 40) {
                //     planeRotation.z += 2
                //     this.el.setAttribute("rotation", planeRotation)
                // }
            }

            if(e.key === "ArrowDown") {
                if(planeRotation.y > -40) {
                    planeRotation.y -= 2
                    this.el.setAttribute("rotation", planeRotation)
                }

                if(planeRotation.z > -1) {
                    planeRotation.z -= 5
                    this.el.setAttribute("rotation", planeRotation)
                }
            }
        })
    }
})